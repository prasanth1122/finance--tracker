import React from 'react';
import "./style.css"


const Footer = () => {
  return (
    <footer className="footer">
     
      <p>&copy; 2023 CoinWaves</p>
    </footer>
  );
}

export default Footer;
