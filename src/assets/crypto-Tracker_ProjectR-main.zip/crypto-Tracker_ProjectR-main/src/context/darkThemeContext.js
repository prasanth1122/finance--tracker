import { createContext } from "react";

const DarkThemeContext=createContext();
export default DarkThemeContext;