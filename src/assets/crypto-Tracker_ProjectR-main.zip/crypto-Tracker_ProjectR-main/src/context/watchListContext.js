import { createContext } from "react";
const watchListContext=createContext();
export default watchListContext;